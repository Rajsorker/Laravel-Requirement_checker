Laravel-Requirement-Checker
===========================

Script independiente para comprobar si un servidor web cumple los requerimientos para correr el framework Laravel.

Uso
---

Coloca el archivo check.php en el servidor web y ábrelo con tu navegador.

Notas
-----

Parte del código fue tomado de la vista por defecto de Laravel y el script Yii Framework Requirement Checker.