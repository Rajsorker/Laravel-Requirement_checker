Laravel-Requirement-Checker
===========================

Standalone script to check if a server meets the requirements for running the Laravel framework.

Use
---

Place the check.php file into the web server and open it with your browser.

Notes
-----

Part of the code was taken from Laravel default view and Yii Framework Requirement Checker script.